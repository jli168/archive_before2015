How to use Vimeo javascript API.
===============================

## basic logic:
we have a window A, and a vimeo iframe B is inside A,  
we can define some events and handlers for window A,  
and tell vimeo iframe to listen to some events that we care.   
So that A can interact with B.

##basic mechanism:
*   window.addEventListener('message', onMessageReceived, false);
*   otherWindow.postMessage(message, targetOrigin, [transfer]);
*   source: https://developer.mozilla.org/en-US/docs/Web/API/Window.postMessage

##implement: 
It is easy for window A to addEventListener and write event handler,   
But how to send message to the vimeo iframe?  


You interact with the player by sending a serialized JSON object with postMessage() to the <iframe>. The following format should be used:
`{
        "method": "methodName",
        "value": "value"
}`  [link](http://developer.vimeo.com/player/js-api)     
code:  
`var player = $('iframe');`  
`player[0].contentWindow.postMessage(data, url);`  
`data` is a json object `{‘method’: ‘addEventListener, ‘value’: ‘play’}`   
which tells vimeo player to add a ‘play’ event listener;   


the interesting thing which I guess is that, now when we postMessage to vimeo like this: `player[0].contentWindow.postMessage({‘method’: ‘play’}, url)`, vimeo’s  **play** event handler will play the video, send message back to our window, in the same json object format. so we can use our **play** event handler to capture that data, know that the video is playing and act accordingly

