readme, let me learn github now


connect to server


change from server!


do it again from server
