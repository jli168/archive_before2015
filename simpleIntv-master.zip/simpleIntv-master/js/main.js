$(document).ready(function(){

	var $controlDiv = $("#controlDiv");
	var $textDiv = $("#textDiv");

	var fadein = function(nIndex, nLen){
		this.style.opacity = nIndex/nLen;
		this.style.visibility = (nIndex > 0 ? 'visible':'hidden');
	}

	var reset = function(){
		this.style.opacity = 1;
		this.style.visibility = 'hidden';
	}

	var si = new SimpleIntv(textDiv, fadein, 500, 10);

	$controlDiv.find('[name="fadein"]').on('click', si.start.bind(si));
	$controlDiv.find('[name="pause"]').on('click', si.pause.bind(si));
	$controlDiv.find('[name="clear"]').on('click', function(){
		si.clear.call(si);
		reset.call($textDiv[0]);
	});

});