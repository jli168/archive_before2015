
(function(window){
	/**
	 * SimpleIntv: wrap setInterval function so it is easy to start, pause and clear a loop
	 * 
	 * @param {[object]} oOwner [the DOM object SimpleIntv is binded to]
	 * @param {[function]} fTask  [the function to call in every loop]
	 * the signature of fTask: function(index, length) 
	 * index: the current loop times. length: total loop times, as nLen
	 * @param {[number]} nRate  [the frequency, 1/1000 second as a unit]
	 * @param {[number]} nLen   [the total loop times]
	 */
	var SimpleIntv = function(oOwner, fTask, nRate, nLen){

		if(! (this && this instanceof SimpleIntv) ){ return ;}
		if(arguments.length<2) {throw new Error("wrong arguments number")}

		this.owner = oOwner;
		this.task  = fTask;
		if( isFinite(nRate) && nRate > 0 ){ this.rate = Math.floor(nRate); }
		if( nLen > 0 ){ this.len = Math.floor(nLen); }
	}

	/* default properties */
	SimpleIntv.prototype.owner = null;
	SimpleIntv.prototype.task = null;
	SimpleIntv.prototype.rate = 1000;
	SimpleIntv.prototype.len = 10;

	/* read only properties */
	SimpleIntv.prototype.SESSION = -1;
	SimpleIntv.prototype.INDEX = 0;
	SimpleIntv.prototype.PAUSED = true;


	/* global functions */

	SimpleIntv.forceCall = function(oSI){
		if(oSI.INDEX > oSI.len){
			return false;
		}
		// console.log(oSI.INDEX);
		oSI.INDEX++;

		return oSI.task.call(oSI.owner, oSI.INDEX, oSI.len);
	}

	/* instance functions */

	SimpleIntv.prototype.start = function(){
		if(this.PAUSED == false) return;

		this.PAUSED = false;

		clearInterval(this.SESSION);

		this.SESSION = setInterval(SimpleIntv.forceCall, this.rate, this);
	}

	SimpleIntv.prototype.pause = function(){
		if(this.PAUSED) return;

		clearInterval(this.SESSION);

		this.PAUSED = true;
	}

	SimpleIntv.prototype.clear = function(){
		this.pause();

		delete this.INDEX;
	}

	/* export SimpleIntv to globle*/
	window.SimpleIntv = SimpleIntv;

})(window)
