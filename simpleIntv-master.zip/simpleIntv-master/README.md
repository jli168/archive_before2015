simpleIntv
==========

#### SimpleIntv: wrap setInterval function so it is easy to start, pause and clear a loop


**The problem**: if you use setInterval to loop your function call, the function is run in the global context, which makes it not easy for us to start, pause and clear the function calling loop.


**The solution**: when you create a new SimpleIntv object, it binds to a DOM object, no more `window` object, and you set the function to be called, the frequency of the loops and how many times you want to loop. 


**The methods**: you basically call `start`, `pause`, and `reset` functions to start, pause and jump out of loop.


**demo**: use index.html to demo fade in effect of text.


**reference**: [setInterval @ Mozzila](https://developer.mozilla.org/en-US/docs/Web/API/WindowTimers.setInterval)


