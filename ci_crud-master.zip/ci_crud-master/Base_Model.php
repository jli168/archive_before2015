<?php
/**
 * This model has functions to handle base CRUD database operations.
 * 
 *@auther Jinsong Li
 */

class Base_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	/**
	 * the _required function with return false if the $options array does not
	 * contain all the keys that are in the $required array. 
	 * @param array $required 
	 * @param array $options
	 * @return boolean
	 */
	protected function _required($required, $options)
	{
		if($required === null) return true;
		foreach( $required as $filed)
		{
			if(!isset($options[$filed])){
				return false;
			}
		}
		return true;
	}
	
	/**
	 * the _default function will combine $options array with a set of default,
	 * giving the value of $option array priority
	 * the $option is now updated, because of & (reference of object)
	 * @param array $default
	 * @param array $options
	 * @return null
	 */
	protected function _default($default, &$options)
	{
		if(count($default)>0)
		{
			$options= array_merge($default, $options);
			
		}
	}
	
	/**
	 * add function creates a new record in the database table,
	 * table name is specified in $options['primary_table']
	 * @param array $required --required fields in the options
	 * @param array $default  --default values for the fields in the options
	 * @parma array $options  --array of fields avalable
	 * 	      values('primary_table'=>'...','user_id'=>'...',....)
	 * 	
	 * @return int ID on success, bool false on fail
	 */
	public function add($required=array(), $default=array(), $options=array())
	{
		
		//make sure $options has all required fields.
		if(!$this->_required($required, $options)){return false;}
		//set default values for $options
		$this->_default($default, $options);

		//the table name to be insert
		$table_name = $options['primary_table'];
		//check if this table exists 
		if(!$this->db->table_exists($table_name)) return false;		
		//the availabe fields of the table.
		$table_fields = $this->db->list_fields($table_name);
		//make sure we don't allow insert into fields not available
		foreach ($table_fields as $field)
		{
			if(isset($options[$field]))
			{
				$this->db->set($field, $options[$field]);
			}
		}
		
		$query = $this->db->insert($table_name);
		//echo 'what is last query '.$this->db->last_query();
		if($query) //insert successful, return  Get the ID generated in the last query
		{	
			return $this->db->insert_id(); 
		}else{
			return false;
		}	
	}
	
	
	/**
	 * get method returns an array of qualified record objects
	 * table name is specified in $options['primary_table']
	 * @param array $required --required fields in the options
	 * @param array $default  --default values for the fields in the options
	 * @parma array $options  --array of fields avalable
	 * 	      values('primary_table'=>'...','user_id'=>'...',....)
	 * @return if the result multiple rows, return a 2-dimentional array 
	 * if the result is a single row, return the single result as an array.
	 * if the result is empty, return an empty array.
	 * if something is wrong, return false.
	 * 
	 */
	public function get($required=array(), $default=array(), $options=array())
	{
		//make sure $options has all required fields.
		if(!$this->_required($required, $options)){return false;}
		//set default values for $options
		$defaults = array(
				'sort_direction' => 'asc'
		);
		$this->_default($default, $options);
		
		//the table name to be get
		$table_name = $options['primary_table'];
		//check if this table exists
		if(!$this->db->table_exists($table_name)) return false;

		//the availabe fields of the table.
		$table_fields = $this->db->list_fields($table_name);
		
		//set 'where' cause 
		foreach ( $table_fields as $field)
		{
			if(isset($options[$field])){
				$this->db->where($field, $options[$field]);
			}			
		}
		
		if (isset($options['limit']) && isset($options['offset']))
		{
			$this->db->limit($options['limit'], $options['offset']);
		}
		else
		{
			if (isset($options['limit']))
			{
				$this->db->limit($options['limit']);
			}
		}
		
		if (isset($options['sort_by']))
		{
			$this->db->order_by($options['sort_by'], $options['sort_direction']);
		}
		
		$query = $this->db->get($table_name);

		if($query->num_rows()>1){ //multiple result set
			return $query->result_array();
		}else if ($query->num_rows() == 1){// zero set
			return $query->row_array();
		}else{
			return false;
		}
	}
	
	
	/**
	 * update function alters a record in the table 
	 * by specify the table's primary key. 
	 * table name is specified in $options['primary_table'],
	 * so the primary key is
	 * @param array $required --required fields in the options
	 * @param array $default  --default values for the fields in the options
	 * @parma array $options  --array of fields avalable
	 * 	      values('primary_table'=>'...','user_id'=>'...',....)
	 *  @return  int affected_rows() or bool if false
	 */
	public function update($required=array(), $default=array(), $options=array())
	{		
		//the table name to be updated
		$table_name = $options['primary_table'];
		//check if this table exists
		if(!$this->db->table_exists($table_name)) return false;

		//make sure $options has all required fields.
		if(!$this->_required($required, $options)){return false;}
		//set default values for $options
		$this->_default($default, $options);
		
		//the availabe fields of the table.
		$table_fields = $this->db->list_fields($table_name);
		//make sure we don't allow insert into fields not available
		foreach ($table_fields as $field)
		{
			if(isset($options[$field]))
			{
				$this->db->set($field, $options[$field]);
			}
		}
		
		//the primary_key for the to-be-updated table row
		//by convention, all all primary keys are defined like this:
		$primary_key = $table_name.'_id';
		$this->db->where($primary_key, $options[$primary_key]);
		$this->db->update($table_name);
		
		//echo $this->db->last_query();
		return $this->db->affected_rows();
	}
	
	/**
	 * delete method removes a record from the table by providing the $options array
	 *
	 * @param array $options,
	 *  values('primary_table'=>'...','user_id'=>'...',....)
	 * @return boolean
	 */	
	
	public function delete($options)
	{
		$required = array('primary_table');
		//make sure $options has all required fields.
		if(!$this->_required($required, $options)){return false;}
		
		//the table name to be insert
		$table_name = $options['primary_table'];
		//check if this table exists
		if(!$this->db->table_exists($table_name)) return false;
		//the availabe fields of the table.
		$table_fields = $this->db->list_fields($table_name);
		
		//set 'where' cause 
		foreach ( $table_fields as $field)
		{
			if(isset($options[$field])){
				$this->db->where($field, $options[$field]);
			}			
		}
		
		return $this->db->delete($table_name);	
	}
	
	
	
}
