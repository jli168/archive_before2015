ci_crud
=======

## CodeIgniter base_model for CRUD

We know that CodeIgniter has Database class for us to interact with database.
but still, everytime we need to fetch a combination of Database methods 
do CRUD (create, read, update, delete).

Extend this model to make your CRUD Database simpler.

## Install and Use 
Just put this file under application/models directory, and include it when you want to extend it.
There are four functions for you to use:
  add($requird, $default, $options);
  get($requird, $default, $options);
  update($requird,  $options),
  delete($options);
  
example: 

I have a user table in my mysql database, like this:
      
    create table user (
      user_id int(10) auto_increment,
      user_name varchar(32),
      user_email varchar(64) not null,
      user_password varchar(255) not null,
      user_country varchar(32),  # which country the user lives
      
      primary key(user_id)
    )


Now I create a new model User to interact with the user table.
the model will be defined as:

    include_once 'Base_Model.php';
    
    class User extends Base_Model 
    {
      /**
      * get the user data by id
      *@param string
      *@return array or false
      */
       public function get_user_by_id($id)
       {
          //sanitize $id first. 
          //prepare query data
          $data = array(
                   'primary_table' => 'user',
                   'user_id'       => $id
                  );
          return $this->get(null, null, $data);
       }
       
       /**
       *  add a new user with the info we have
       *@param array, containing the 'primary_table'=>'user', and other info of the user
       *@return string or false
       */
       public function add_user($options)
       {
          $required = array('primary_table');
          $default  = array(
                        'user_country' => 'U.S.A.'
                      );
          //do some data sanitations
          //now add data
          return $this->add($required, $default, $options);
       }
      
    }


