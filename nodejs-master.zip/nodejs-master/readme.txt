


first i build the bare-bone, make it work, then add features in it,
 and then polish it.
